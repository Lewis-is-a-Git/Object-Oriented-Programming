/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   User.cpp
 * Author: lewis
 * 
 * Created on 6 November 2019, 2:40 PM
 */

#include "User.h"
#include <string>
#include <iostream>

User::User(std::string name) {
    _name = name;
}

User::~User() {
}


