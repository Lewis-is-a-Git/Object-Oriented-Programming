/* 
 * File:   main.cpp
 * Author: sfu
 *
 * Created on February 1, 2016, 1:55 PM
 */

#include<iostream>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    cout<<"Hello World"<<endl;
    return 0;
}

