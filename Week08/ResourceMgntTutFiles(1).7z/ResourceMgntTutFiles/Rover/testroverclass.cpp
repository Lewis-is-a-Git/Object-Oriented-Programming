/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * File:   testroverclass.cpp
 * Author: sfu
 *
 * Created on Apr 11, 2018, 9:37:29 AM
 */

#include "testroverclass.h"


CPPUNIT_TEST_SUITE_REGISTRATION(testroverclass);

testroverclass::testroverclass() {
}

testroverclass::~testroverclass() {
}

void testroverclass::setUp() {
}

void testroverclass::tearDown() {
}

void testroverclass::testMethod() {
    CPPUNIT_ASSERT(true);
}

void testroverclass::testFailedMethod() {
    CPPUNIT_ASSERT(false);
}

