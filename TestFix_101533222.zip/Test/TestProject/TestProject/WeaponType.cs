﻿// FileName: EmptyClass.cs
// Author: Lewis Brockman-Horsley
// Email: 101533222@students.swinburne.edu.au
// Date: 5/11/2019
using System;
namespace TestProject
{
    public enum WeaponType
    {
        Sword,
        Spear,
        Bow
    }
}
