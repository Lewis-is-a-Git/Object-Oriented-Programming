﻿// FileName: Media.cs
// Author: Lewis Brockman-Horsley
// Email: 101533222@students.swinburne.edu.au
// Date: 4/09/2019
using System;
namespace MediaOrganiser
{
    /// <summary>
    /// Creates different types of media objects.
    /// </summary>
    public class Media
    {
        private string _title;
        private int _size;
        private MediaType _type;

        /// <summary>
        /// Initializes a new instance of the <see cref="T:MediaOrganiser.Media"/> class.
        /// </summary>
        /// <param name="title">Title of media.</param>
        /// <param name="size">Size of media file.</param>
        /// <param name="type">Type of the media.</param>
        public Media(string title, int size, MediaType type)
        {
            _title = title;
            _size = size;
            _type = type;
        }

        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }
        public int Size
        {
            get
            {
                return _size;
            }
            set
            {
                _size = value;
            }
        }
        public MediaType Type
        {
            get
            {
                return _type;
            }
        }

        /// <summary>
        /// Play the media by returning a string to show that it is playing.
        /// </summary>
        /// <returns>A string based on the type of media played</returns>
        public string Play()
        {
            if (_type == MediaType.Audio)
            {
                return "Ready for some light music!\n";
            }
            else if (_type == MediaType.Video)
            {
                return "Be entertained by the visual effect!\n";
            }
            else if (_type == MediaType.Image)
            {
                return "High resolution image provided!\n";
            }
            else { return "Invalid File Type\n"; }
        }
    }
}
